%% Median Surface
% Isaac B. Breinyn 2020
%
% A script for analyzing the muscle layer of the Drosophila midgut after
% prepared via an ImSaNE pipeline as well as trained on using Ilastik
%
% TO DO BEFORE RUNNING: Run setup.m from ImsaneV1.2.3 and muscle_surface_Pipeline.m and train on the
% muscle data in Ilastik. Have outputted probabilities ready.

%% Clean Matlab and set Global Parameters

% clean the terminal and all variables, close all open figures

clear; close all; clc;

% add any necessary paths

addpath_recurse('F:/Streichan/code/gut_matlab/') ;

% THINGS TO CHANGE BETWEEN DATASETS %%%%%%% 

dataDir = 'F:\Streichan\data\202003111830_mef2gal4klarUASCAAXmChHiFP_wo_63x_e4e5\2038_e5\' ; % working directory
fn = '2038_e5_Ch1_T%02d' ; % working file name
ssfactor = 2 ; % the subsampling factor of your muscle data (used later to return to origonal aspect ratio)
ltp = 26 ; % the last TP of your datasets (this will be used for iterating over your dataset)
ifg = 1   ; % the channel that corresponds to the fg of your outputted probabilities (1 or 2) (ilastik foreground)
dataChannel = 1 ; % the channel used for your raw data (1 or 2)
fileMeta.stackResolution    = [.0401 .0401 1.4996];
fsize = [1024 512 412] ;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

cd(dataDir)

xp = project.Experiment(dataDir, dataDir);

fileMeta                    = struct();
fileMeta.dataDir            = dataDir;
fileMeta.filenameFormat     = [fn, '.tiff'];
fileMeta.nChannels          = 2;
fileMeta.timePoints         = round(linspace(1, ltp, ltp));
fileMeta.swapZT             = 0;

xp.setFileMeta(fileMeta);

first_tp = 1 ;
expMeta                     = struct();
expMeta.channelsUsed        = [1 2];

xp.setExpMeta(expMeta);
%% Load and Mask Data using Training

fnp = [fn, '_Probabilities'] ; % Outputted probabilities file name
ssfArray = ones(ssfactor, ssfactor, ssfactor) ; % create cubic 3D array the size of your ssfactor in each dim to perform kronecker tensor product

for tt = 20 %1:ltp % iterate over timepoints in the datasaet
    %for dataChannel = 1:2
    
    rawData = h5read([sprintf(fn,tt), '.h5'], '/inputData') ; % load raw data of this particular timepoint
        probField = h5read([sprintf(fnp,tt), '.h5'], '/exported_data') ; % outputed prob from Ilastik corresponding to this timepoint
            probField = squeeze(probField(ifg,:,:,:) ) ;

        [maskedData, medianValues] = projectMaskedSurface(double(rawData), probField, 2) ;
        
%     rawData = squeeze(rawData(1, :, :,:)) ;
    rawData = superkron(rawData, ssfArray) ; % take kronicker tensor product to "undownsample" the probability field

    probField = superkron(probField, ssfArray) ; % take kronicker tensor product to "undownsample" the probability field
    probField = probField(:,:,1:size(rawData, 3)) ;
    
    % Implement conncomping to clean up the prob field (WARNING: SLOW)
    cPF = bwconncomp(probField) ;
    P = length(cPF.PixelIdxList) ;
    probField = bwareaopen(probField, P) ;
    
    maskData = uint8(rawData.*probField) ; % mask the origonal data using the origonal aspect ratio probabilities from ilastik
    
    
    
    storedMaskData(dataChannel,:,:,:) = maskData ;
    %
    %         if dataChannel == 1
    fnm = [fn '_membraneMask'] ;
    %         elseif dataChannel == 2
    %             fnm = [fn '_nucleiMask'] ;
    %         end
    
    saveastiff(maskData, fullfile(dataDir, [sprintf(fnm, tt), '.tiff']))  ;
    disp(['Saving ', sprintf(fnm, tt), '.tiff']) ;
end

% Now make overlayed MIP

channel1 = uint8(squeeze(storedMaskData(1,:,:,15:132))) ;
channel2 = uint8(squeeze(storedMaskData(2,:,:,15:132))) ;
channel1 = max(channel1, [], 3) ; % take the maximum value along the z-dim
channel2 = max(channel2, [], 3) ; % take the maximum value along the z-dim
channel1 = imadjust(0.5*channel1) ;
channel2 = imadjust(0.5*channel2) ;
channelsum = uint8(channel1 + channel2) ;
channelsum = (channelsum) ;
channelsum(channelsum>255) = 255 ; % clip the summed data
overlay = cat(3, channel2, channel1, channelsum) ;
imwrite(overlay, fullfile(dataDir, [sprintf(fn, tt), '_MIP.png']))  ;
%disp(['Saving ', sprintf(fnm, tt), '_MIP.tif']) ;
%end

%% Extract Median Surface using Masked Data

fnp = [fn, '_Probabilities'] ; % Outputted probabilities file name
ssfArray = ones(ssfactor, ssfactor, ssfactor) ; % create cubic 3D array the size of your ssfactor in each dim to perform kronecker tensor product

% initiate a matrix that will store surface data for each tp
surfaceArray = zeros(ltp, fsize(1), fsize(2)) ;

% Create coord list for delaunay
[X,Y] = meshgrid(1:fsize(1),1:fsize(2)) ;
xy = [X(:), Y(:)] ;

for tt = 1:ltp % iterate over all tps in the dataset
    close all
    
    probField = h5read([sprintf(fnp,tt), '.h5'], '/exported_data') ; % outputed prob from Ilastik corresponding to this timepoint
    probField = squeeze(probField(1,:,:,:) ) ;
    probField = permute(probField, [2 1 3]) ; % permute the prob array
    probField = superkron(probField, ssfArray) ; % take kronicker tensor product to "undownsample" the probability field
    
    % Implement conncomping to clean up the prob field
    
    probField(probField<0.4) = 0 ; % threshold the probability field
    cPF = bwconncomp(probField) ; % get the concomp struct of the prob field
    seg = zeros(size(probField), 'logical') ; % build a bw array the same size of the prob field (segmentation)
    seg(cPF.PixelIdxList{1}) = true ;
    
    stats = regionprops3(cPF) ; % extract geometric stats of each volume in the segmentation
    threshold = 1e5 ; % assign the upper threshold of all volumes to be removed
    removeMask = [stats.Volume]<threshold ;
    seg(cat(1,cPF.PixelIdxList{removeMask})) = false ; % remove all bodies with volume < threshold
    
    [~,~, zidx] = meshgrid(1:size(seg,2), 1:size(seg,1), 1:size(seg,3)) ; % build an array the same size of segmentation but all values in a slice are equal to that slice's z coord
    bw = double(seg) .* zidx ; % mask the array by the segmentation
    bw(bw == 0) = NaN ; % NaN any zeros
    medianz = nanmedian(bw, 3) ; % take the nanmedian of the array (this is median height(x,y) of the segmentaion)
    medianz = inpaint_nans(medianz, 2) ; % interpolate over NaNs
    
    % smooth and interpolate data
    %medianz = imgaussfilt(medianz) ; % smooth the data using a gaussian
    
    % store the surface in an array that will later be used to make MIPs
    surfaceArray(tt, :, :) = medianz ;
    
    tri = delaunay(xy) ;  % create delauney triangulation of xy coords of centdata
    trisurf(tri, xy(:, 1), xy(:,2), medianz(:), 'EdgeColor', 'none')
    caxis([0 105]) ;
    title('Visualization of Muscle Surface for e4') ;
    view(2)
    fns = [fn '_trisurf'] ;
    saveas(gcf, sprintf(fns,tt), 'png') ;
    
end
save(fullfile(cd, 'surfaceArray.mat'), 'surfaceArray') ;

%% Making collection of plots showing this pipeline

fnp = [fn, '_Probabilities'] ; % Outputted probabilities file name
ssfArray = ones(ssfactor, ssfactor, ssfactor) ; % create cubic 3D array the size of your ssfactor in each dim to perform kronecker tensor product

if ~exist('xy')
    [X,Y] = meshgrid(1:fsize(1),1:fsize(2)) ;
    xy = [X(:), Y(:)] ;
end

if ~exist('surfaceArray') % if the var surfaceArray does not exist, load it in from hardrive
    load(fullfile(cd, 'surfaceArray.mat'), 'surfaceArray') ;
end

storedMaskData = zeros(2, fsize(1),  fsize(2), fsize(3)) ;
storedRawData = zeros(2, fsize(1), fsize(2), fsize(3)) ;

sigmam = 1 ; % the amount of pixels below the median surface that will be masked
sigmap = 1 ; % the amount of pixels above the median surface that will be masked

for tt =1:size(surfaceArray, 1) % iterate over timepoints in the datasaet
    mask = squeeze(surfaceArray(tt, :, :)) ; % extract z(x,y) position from surfaceArray
    
    
    rawData = h5read([sprintf(fn,tt), '.h5'], '/inputData') ; % load raw data of this particular timepoint
    %         rawData = squeeze(rawData(dataChannel, :, :,:)) ;
    rawData = superkron(rawData, ssfArray) ; % take kronicker tensor product to "undownsample" the probability field
%     
%     for dataChannel = 1:2
%         
%         rawData = data{dataChannel} ; % extract array from cell
        rawData = permute(rawData, [2 1 3]) ;
        
        storedRawData(dataChannel,:,:,:) = rawData ;
        
        maskData = zeros(size(rawData)) ; % create an array of zeros the size of the raw data
        
        for x = 1:size(rawData, 1)
            for y = 1:size(rawData, 2)
                z = round(mask(x,y)) ; % extract median surface value from the mask
                
                if z - sigmam < 1
                    zmin = 1 ;
                else
                    zmin = z - sigmam ;
                end
                
                if z + sigmap > 132
                    zmax = 132 ;
                else
                    zmax = z + sigmap ;
                end
                
                maskData(x,y,zmin:zmax) = rawData(x,y,zmin:zmax) ;
            end
        end
        storedMaskData(dataChannel,:,:,:) = maskData ;
    % end
    
    probField = h5read([sprintf(fnp,tt), '.h5'], '/exported_data') ; % outputed prob from Ilastik corresponding to this timepoint
    probField = squeeze(probField(1,:,:,:) ) ;
    probField = permute(probField, [2 3 1]) ; % permute the prob array
    probField = superkron(probField, ssfArray) ; % take kronicker tensor product to "upsample" the probability field
    
    % Implement conncomping to clean up the prob field
    
    probField(probField<0.4) = 0 ; % threshold the probability field
    cPF = bwconncomp(probField) ; % get the concomp struct of the prob field
    seg = zeros(size(probField), 'logical') ; % build a bw array the same size of the prob field (segmentation)
    seg(cPF.PixelIdxList{1}) = true ;
    
    stats = regionprops3(cPF) ; % extract geometric stats of each volume in the segmentation
    threshold = 1e5 ; % assign the upper threshold of all volumes to be removed
    removeMask = [stats.Volume]<threshold ;
    seg(cat(1,cPF.PixelIdxList{removeMask})) = false ; % remove all bodies with volume < threshold
    
    % At this point we have raw data (rawData), masked Data (storedData),
    % ilastik probabilities (probField), and segmentation (seg). We are now
    % going to take cross sections at x = 256 and y = 256, and plot each of
    % these things with the median curve overlayed
    
    slice = 256 ; % Define the slice you want to make the cross section at
    
    % These vectors will be what we plot the median curve against
    ixslice = zeros(size(xy)) ;
    iyslice = zeros(size(xy)) ;
    
    ixslice = xy.*horzcat((xy(:,1) == slice),(xy(:,1) == slice)) ;
    iyslice = xy.*horzcat((xy(:,2) == slice),(xy(:,2) == slice)) ;
    
    ixslice(ixslice == 0) = nan ;
    iyslice(iyslice == 0) = nan ;
    
    ixslice = flipud(ixslice) ;
    iyslice = flipud(iyslice) ;
    
    figure('units','normalized','outerposition',[0 0 1 1]) % Create full screen figure to then populate with plots
    
    % First plot is going to be the raw data (xz view) overlayed with the median
    subplot(2, 3, 1) ;
    xch1 = uint8(squeeze(storedRawData(1, (slice-10):(slice+10), :, :))) ;
    xch2 = uint8(squeeze(storedRawData(2, (slice-10):(slice+10), :, :))) ;
    xch1 = imadjust(uint8(squeeze(mean(xch1, 1)))) ;
    xch2 = imadjust(uint8(squeeze(mean(xch2, 1)))) ;
    xsum = uint8(xch1 + xch2) ;
    xsum(xsum > 255) = 255 ;
    xover = cat(3, xch2, xch1, xsum) ;
    imshow(rot90(xover, 3), [] )  ;
    hold on
    scatter(ixslice(:,2), mask(:), 3, 'yellow') ;
    scatter(ixslice(:,2), mask(:) - 20, 3, 'cyan') ;
    scatter(ixslice(:,2), mask(:) + 22, 3, 'cyan') ;
    scatter(ixslice(:,2), mask(:) + 23, 3, 'magenta') ;
    scatter(ixslice(:,2), mask(:) + 90, 3, 'magenta') ;
    set(gca, 'YDir', 'normal') ;
    title('XZ View of Raw Data with Median Surface')
    
    % Second plot is going to be the raw data (yz view) overlayed with the
    % median
    subplot(2, 3, 4) ;
    ych1 = uint8(squeeze(storedRawData(1,:,(slice-10):(slice+10), :))) ;
    ych2 = uint8(squeeze(storedRawData(2,:,(slice-10):(slice+10), :))) ;
    ych1 = imadjust(uint8(squeeze(mean(ych1, 2)))) ;
    ych2 = imadjust(uint8(squeeze(mean(ych2, 2)))) ;
    ysum = uint8(ych1 + ych2) ;
    ysum(ysum > 255) = 255 ;
    yover = cat(3, ych2, ych1, ysum) ;
    imshow(rot90(yover, 3), [] )  ;
    hold on
    scatter(iyslice(:,1), mask(:), 3, 'yellow') ;
    set(gca, 'YDir', 'normal') ;
    title('YZ View of Raw Data with Median Surface')
    
    % Third plot is going to be the ilastik probabilities (xz view)
    % overlayed with the median
    subplot(2, 3, 2) ;
    xim = squeeze((mean(probField((slice - 10):(slice+10), :, :), 1))) ;
    imshow(rot90(xim, 3), [] )  ;
    hold on
    scatter(ixslice(:,2), mask(:), 5) ;
    set(gca, 'YDir', 'normal') ;
    title('XZ View of Ilastik Probabilities with Median Surface')
    
    % Fourth plot is going to be the ilastik probabilities (yz view)
    % overlayed with the median
    subplot(2, 3, 5) ;
    yim = squeeze((mean(probField(:,(slice - 10):(slice+10), :), 2))) ;
    imshow(rot90(yim, 3), [] )  ;
    hold on
    scatter(iyslice(:,1), mask(:), 5) ;
    set(gca, 'YDir', 'normal') ;
    title('YZ View of Ilastik Probabilities with Median Surface')
    
    % Fifth plot is going to be the segmentation (xz view) overlayed with
    % the median
    subplot(2, 3, 3) ;
    xim = squeeze((mean(seg((slice - 10):(slice+10), :, :), 1))) ;
    imshow(rot90(xim, 3), [] )  ;
    hold on
    scatter(ixslice(:,2), mask(:), 5) ;
    set(gca, 'YDir', 'normal') ;
    title('XZ View of Segmentation with Median Surface')
    
    % Sixth plot is going to be the segmentation (yz view) overlayed with
    % the median
    subplot(2, 3, 6) ;
    yim = squeeze((mean(seg(:,(slice - 10):(slice+10), :), 2))) ;
    imshow(rot90(yim, 3), [] )  ;
    hold on
    scatter(iyslice(:,1), mask(:), 5) ;
    set(gca, 'YDir', 'normal') ;
    title('YZ View of Segmentation with Median Surface')
    
    if ~exist(fullfile(dataDir, 'PipelineImages'))
        mkdir(fullfile(dataDir, 'PipelineImages')) ;
    end
    
    saveas(gcf, fullfile(dataDir, 'PipelineImages', sprintf('Pipeline_T%02d', tt)), 'png') ;
    close all
end

%% Make Median MIPs
% This section uses the extracted median surface to make MIPs of the region
% of data that lives nearby the median surface.

if ~exist('surfaceArray') % if the var surfaceArray does not exist, load it in from hardrive
    load(fullfile(cd, 'surfaceArray.mat'), 'surfaceArray') ;
end

% Now make overlayed MIP
for tt = 1:size(surfaceArray, 1)
    mask = round(squeeze(surfaceArray(tt, :, :))) ; % extract z(x,y) position from surfaceArray
    xp.loadTime(tt) ; % load current TP
    xp.rescaleStackToUnitAspect() ; % rescale to unit aspect ratio
    data = xp.stack.image.apply() ; % save to a variable
    
    for dataChannel = 1:2
        
        rawData = data{dataChannel} ; % load the appropriate channel
        
        [xx,yy] = meshgrid(1:size(rawData, 1), 1:size(rawData, 2));
        mask3d = false(size(rawData)) ; % initiate a boolean 3D array that will mask the rawData
        
        xmax = size(rawData, 1) ;
        ymax = size(rawData, 2) ;
        zmax = size(rawData, 3) ;
        
        if dataChannel == 1
            lowbnd = -15 ;
            upbnd = 20 ;
        elseif dataChannel == 2
            lowbnd = 23 ;
            upbnd = zmax ;
        end
        
        for chadd = lowbnd:upbnd
            % what page to set to true?
            zind = mask + chadd ;
            % convert to linear index
            lin = (zind - 1) * xmax * ymax + (xx-1)*ymax + yy;
            % clip linear indices to be inside volume
            lin = lin(lin > 0) ;
            lin = lin(lin < xmax * ymax * zmax) ;
            % Set this layer to be true
            mask3d(lin) = true ;
        end
        
        maskedData= uint8(rawData).*uint8(mask3d) ; % mask the raw data using our boolean 3d mask
        
        maskedData = imadjust(uint8(max(maskedData, [], 3))) ; % take the max value along the z-dim and adjust to new map
        
        if dataChannel == 1
            overlay = cat(3, zeros(size(maskedData)) ,maskedData, maskedData) ;
        elseif dataChannel == 2
            overlay = cat(3, maskedData, zeros(size(maskedData)), maskedData) ;
        end
        
        imshow(overlay) ;
        fnMasked = 'midfold_e4_T%02d_Ch%01d' ;
        imwrite(maskedData, fullfile(dataDir, ['masked_ch',num2str(dataChannel)], [sprintf(fnMasked, tt, dataChannel), '_overlayMIP_masked.tiff']))  ;
        close all
    end
end
